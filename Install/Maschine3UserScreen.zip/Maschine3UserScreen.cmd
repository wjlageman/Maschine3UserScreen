@echo off
rem "c:/Program Files/Maschine3UserScreen/" is the usual installation folder
rem "c:/Program Files/Maschine3UserScreen/Maschine3UserScreen/Maschine3UserScreen.exe" index.htm
rem Replace next line if you change the installation folder
"%~dp0Maschine3UserScreen/Maschine3UserScreen.exe" index.htm
